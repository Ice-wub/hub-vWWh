import json
import logging
import time
import uuid
from typing import Any

from redis_ai_cache.core.base import RedisComponent
from redis_ai_cache.core.embedding import EmbeddingProvider, HFTextVectorizer
from redis_ai_cache.cache.semantic_cache import cosine_similarity

logger = logging.getLogger(__name__)


class SemanticMessageHistory(RedisComponent):
    """存储和检索对话历史，支持语义搜索。

    Args:
        name: 会话名称（用作 Redis 键前缀）
        redis_url: Redis 连接 URL
        distance_threshold: 语义检索阈值（默认 0.7）
        max_tokens: 返回的最大上下文长度（字符数）
        embedding_provider: 嵌入提供者
    """

    def __init__(
        self,
        name: str,
        redis_url: str = "redis://localhost:6379",
        distance_threshold: float = 0.7,
        max_tokens: int = 4000,
        embedding_provider: EmbeddingProvider | None = None,
    ):
        super().__init__(name=name, redis_url=redis_url)
        self.distance_threshold = distance_threshold
        self.max_tokens = max_tokens
        self.embedding_provider = embedding_provider or HFTextVectorizer()

    def add_messages(self, messages: list[dict[str, Any]]) -> list[str]:
        """添加消息到历史记录。

        每条消息应包含:
            - role: system / user / llm / tool
            - content: 消息内容
            - metadata (可选): 附加信息字典

        Args:
            messages: 消息列表

        Returns:
            消息 ID 列表
        """
        ids = []
        pipeline = self.client.pipeline()

        for msg in messages:
            msg_id = str(uuid.uuid4())
            ids.append(msg_id)
            key = self._key(msg_id)

            data = {
                "id": msg_id,
                "role": msg.get("role", "user"),
                "content": msg.get("content", ""),
                "timestamp": str(int(time.time())),
                "metadata": json.dumps(msg.get("metadata", {}), ensure_ascii=False),
            }

            # 对 user 和 llm 消息存储嵌入
            if msg.get("role") in ("user", "llm") and msg.get("content"):
                try:
                    data["embedding"] = self._serialize(
                        self.embedding_provider.embed(msg["content"])
                    )
                except Exception as e:
                    logger.warning("消息嵌入计算失败: %s", e)

            pipeline.hset(key, mapping=data)

        try:
            pipeline.execute()
        except Exception as e:
            logger.warning("SemanticMessageHistory.add_messages 失败: %s", e)

        return ids

    def get_recent(self, k: int = 10) -> list[dict[str, Any]]:
        """获取最近 k 条消息（按时间戳排序）。"""
        try:
            keys = self.client.keys(self._key("*"))
        except Exception as e:
            logger.warning("SemanticMessageHistory.get_recent 失败: %s", e)
            return []

        messages = []
        for key in keys:
            try:
                data = self.client.hgetall(key)
                msg = self._decode_message(data)
                msg["_ts"] = int(data.get(b"timestamp", data.get("timestamp", 0)) if isinstance(data.get(b"timestamp", data.get("timestamp", 0)), (int, float)) else 0)
                messages.append(msg)
            except Exception as e:
                logger.warning("解析消息失败: %s", e)
                continue

        messages.sort(key=lambda x: x["_ts"], reverse=True)
        for m in messages:
            m.pop("_ts", None)
        return messages[:k]

    def search(self, query: str, k: int = 5) -> list[dict[str, Any]]:
        """在对话历史中语义搜索。

        Args:
            query: 搜索查询
            k: 最大返回数

        Returns:
            按相似度排序的消息列表
        """
        query_embedding = self.embedding_provider.embed(query)

        try:
            keys = self.client.keys(self._key("*"))
        except Exception as e:
            logger.warning("SemanticMessageHistory.search 失败: %s", e)
            return []

        scored = []
        for key in keys:
            try:
                data = self.client.hgetall(key)
                embedding_raw = data.get(b"embedding", data.get("embedding"))
                if embedding_raw is None:
                    continue

                stored_embedding = self._deserialize(
                    embedding_raw.decode() if isinstance(embedding_raw, bytes) else embedding_raw
                )
                if not stored_embedding:
                    continue

                dist = cosine_similarity(query_embedding, stored_embedding)
                if dist <= self.distance_threshold:
                    msg = self._decode_message(data)
                    msg["distance"] = round(dist, 4)
                    scored.append(msg)
            except Exception as e:
                logger.warning("语义搜索解析条目失败: %s", e)
                continue

        scored.sort(key=lambda x: x["distance"])
        return scored[:k]

    def clear(self) -> None:
        """清空该会话的所有历史消息。"""
        try:
            keys = self.client.keys(self._key("*"))
            if keys:
                self.client.delete(*keys)
        except Exception as e:
            logger.warning("SemanticMessageHistory.clear 失败: %s", e)

    def _decode_message(self, data: dict) -> dict[str, Any]:
        """将 Redis hgetall 结果解码为消息字典。"""
        decoded = {}
        for k, v in data.items():
            key = k.decode() if isinstance(k, bytes) else k
            val = v.decode() if isinstance(v, bytes) else v
            decoded[key] = val

        msg = {
            "role": decoded.get("role", "user"),
            "content": decoded.get("content", ""),
        }
        if "metadata" in decoded:
            try:
                msg["metadata"] = json.loads(decoded["metadata"])
            except json.JSONDecodeError:
                pass
        return msg
