import logging
import uuid
from typing import Any

from redis_ai_cache.core.base import RedisComponent
from redis_ai_cache.core.embedding import EmbeddingProvider, HFTextVectorizer

logger = logging.getLogger(__name__)


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """计算两个向量之间的余弦距离（0=完全相同, 1=完全无关）。"""
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = sum(x * x for x in a) ** 0.5
    norm_b = sum(x * x for x in b) ** 0.5
    if norm_a == 0 or norm_b == 0:
        return 1.0
    return 1 - (dot / (norm_a * norm_b))


class SemanticCache(RedisComponent):
    """使用语义相似度缓存 LLM 问答对。

    相同或相似的 prompt 将命中缓存，避免重复调用大模型。

    Args:
        name: 缓存名称（用作 Redis 键前缀）
        ttl: 缓存条目过期时间（秒）
        redis_url: Redis 连接 URL
        distance_threshold: 缓存命中的最大余弦距离（默认 0.1）
        embedding_provider: EmbeddingProvider 实例，默认使用 HFTextVectorizer
    """

    def __init__(
        self,
        name: str,
        ttl: int = 3600,
        redis_url: str = "redis://localhost:6379",
        distance_threshold: float = 0.1,
        embedding_provider: EmbeddingProvider | None = None,
    ):
        super().__init__(name=name, redis_url=redis_url, ttl=ttl)
        self.distance_threshold = distance_threshold
        self.embedding_provider = embedding_provider or HFTextVectorizer()

    def store(
        self,
        prompt: str,
        response: str,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """存储问答对。

        Args:
            prompt: 用户提问
            response: LLM 回答
            metadata: 附加元数据

        Returns:
            条目 ID
        """
        entry_id = str(uuid.uuid4())
        embedding = self.embedding_provider.embed(prompt)
        key = self._key(entry_id)

        data = {
            "id": entry_id,
            "prompt": prompt,
            "response": response,
            "embedding": self._serialize(embedding),
            "metadata": self._serialize(metadata or {}),
        }

        try:
            self.client.hset(key, mapping=data)
            if self.ttl:
                self.client.expire(key, self.ttl)
        except Exception as e:
            logger.warning("SemanticCache.store 失败: %s", e)

        return entry_id

    def check(self, prompt: str, k: int = 5) -> list[dict[str, Any]]:
        """检查缓存中是否有语义相似的 prompt。

        Args:
            prompt: 用户提问
            k: 最多返回的结果数

        Returns:
            按相似度排序的匹配结果列表，未命中返回空列表。
            每条结果包含 response、prompt、distance 等字段。
        """
        query_embedding = self.embedding_provider.embed(prompt)

        try:
            keys = self.client.keys(self._key("*"))
        except Exception as e:
            logger.warning("SemanticCache.check 查询键失败: %s", e)
            return []

        results = []
        for key in keys:
            try:
                data = self.client.hgetall(key)
                if not data:
                    continue
                stored_embedding = self._deserialize(data.get(b"embedding", data.get("embedding", "[]")))
                if not stored_embedding:
                    continue
                dist = cosine_similarity(query_embedding, stored_embedding)
                if dist <= self.distance_threshold:
                    results.append({
                        "response": data.get(b"response", data.get("response", b"")).decode() if isinstance(data.get(b"response", data.get("response", b"")), bytes) else data.get("response", ""),
                        "prompt": data.get(b"prompt", data.get("prompt", b"")).decode() if isinstance(data.get(b"prompt", data.get("prompt", b"")), bytes) else data.get("prompt", ""),
                        "distance": round(dist, 4),
                        "metadata": self._deserialize(
                            data.get(b"metadata", data.get("metadata", "{}"))
                        ) or {},
                    })
            except Exception as e:
                logger.warning("SemanticCache.check 解析条目失败: %s", e)
                continue

        results.sort(key=lambda x: x["distance"])
        return results[:k]

    def clear(self) -> None:
        """清除该缓存名称下的所有条目。"""
        try:
            keys = self.client.keys(self._key("*"))
            if keys:
                self.client.delete(*keys)
        except Exception as e:
            logger.warning("SemanticCache.clear 失败: %s", e)
