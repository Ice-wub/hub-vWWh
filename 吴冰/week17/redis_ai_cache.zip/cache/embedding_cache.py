import hashlib
import logging
from typing import Any

from redis_ai_cache.core.base import RedisComponent

logger = logging.getLogger(__name__)


class EmbeddingCache(RedisComponent):
    """缓存文本到嵌入向量的转换结果，避免重复计算。

    Args:
        name: 缓存名称
        redis_url: Redis 连接 URL
        ttl: 过期时间（秒，默认 3600）
    """

    def __init__(
        self,
        name: str = "embed_cache",
        redis_url: str = "redis://localhost:6379",
        ttl: int = 3600,
    ):
        super().__init__(name=name, redis_url=redis_url, ttl=ttl)

    def store(self, text: str, embedding: list[float]) -> bool:
        """缓存文本对应的嵌入向量。

        Args:
            text: 输入文本
            embedding: 嵌入向量

        Returns:
            是否成功
        """
        key = self._key(self._text_hash(text))
        try:
            self.client.set(key, self._serialize(embedding))
            if self.ttl:
                self.client.expire(key, self.ttl)
            return True
        except Exception as e:
            logger.warning("EmbeddingCache.store 失败: %s", e)
            return False

    def get(self, text: str) -> list[float] | None:
        """获取缓存的嵌入向量。

        Args:
            text: 输入文本

        Returns:
            嵌入向量，未命中返回 None
        """
        key = self._key(self._text_hash(text))
        try:
            data = self.client.get(key)
            if data is None:
                return None
            return self._deserialize(data)
        except Exception as e:
            logger.warning("EmbeddingCache.get 失败: %s", e)
            return None

    def clear(self) -> None:
        """清除所有缓存的嵌入。"""
        try:
            keys = self.client.keys(self._key("*"))
            if keys:
                self.client.delete(*keys)
        except Exception as e:
            logger.warning("EmbeddingCache.clear 失败: %s", e)

    @staticmethod
    def _text_hash(text: str) -> str:
        """对文本取 SHA256 哈希作为键。"""
        return hashlib.sha256(text.encode("utf-8")).hexdigest()
