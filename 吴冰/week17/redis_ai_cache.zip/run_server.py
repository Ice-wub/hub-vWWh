import uvicorn
from api_server import app
uvicorn.run(app, host="0.0.0.0", port=8001, log_level="info")
