import json
import logging
from abc import ABC, abstractmethod
from typing import Any

from redis import Redis

from redis_ai_cache.core.connection import get_redis_client

logger = logging.getLogger(__name__)


class RedisComponent(ABC):
    """所有 Redis 组件的基类，封装公共的连接和键管理逻辑。"""

    def __init__(
        self,
        name: str,
        redis_url: str = "redis://localhost:6379",
        ttl: int | None = None,
        **kwargs: Any,
    ):
        self.name = name
        self.redis_url = redis_url
        self.ttl = ttl
        self._client: Redis | None = None

    @property
    def client(self) -> Redis:
        if self._client is None:
            self._client = get_redis_client(self.redis_url)
        return self._client

    def _key(self, *parts: str) -> str:
        """生成带命名空间的 Redis 键。"""
        return f"{self.name}:" + ":".join(parts)

    def _serialize(self, obj: Any) -> str:
        """将 Python 对象序列化为 JSON 字符串。"""
        return json.dumps(obj, ensure_ascii=False, default=str)

    def _deserialize(self, data: str | None) -> Any | None:
        """将 JSON 字符串反序列化为 Python 对象。"""
        if data is None:
            return None
        try:
            return json.loads(data)
        except (json.JSONDecodeError, TypeError) as e:
            logger.warning("反序列化失败: %s", e)
            return None

    def _handle_redis_error(self, operation: str, fallback: Any = None) -> Any:
        """装饰器风格的错误处理，用于 Redis 操作降级。"""
        # 调用方在 except 块中使用此方法记录警告
        pass

    @abstractmethod
    def clear(self) -> None:
        """清空该组件的所有数据。"""
