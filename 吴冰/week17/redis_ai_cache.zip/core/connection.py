import redis
from redis import Redis
from redis.connection import ConnectionPool


_redis_pools: dict[str, ConnectionPool] = {}


def get_redis_client(
    redis_url: str = "redis://localhost:6379",
    pool_size: int = 10,
    socket_timeout: float = 5.0,
    socket_connect_timeout: float = 3.0,
    decode_responses: bool = True,
) -> Redis:
    """创建或复用 Redis 连接池，返回客户端实例。

    Args:
        redis_url: Redis 连接 URL，如 "redis://localhost:6379/0"
        pool_size: 连接池大小
        socket_timeout: Socket 操作超时（秒）
        socket_connect_timeout: 连接超时（秒）
        decode_responses: 是否自动解码响应为字符串

    Returns:
        redis.Redis 客户端实例
    """
    if redis_url not in _redis_pools:
        _redis_pools[redis_url] = redis.ConnectionPool().from_url(
            redis_url,
            max_connections=pool_size,
            socket_timeout=socket_timeout,
            socket_connect_timeout=socket_connect_timeout,
            decode_responses=decode_responses,
        )
    return Redis(connection_pool=_redis_pools[redis_url])


def close_all_connections() -> None:
    """关闭所有 Redis 连接池。"""
    for pool in _redis_pools.values():
        pool.disconnect()
    _redis_pools.clear()
