import logging
from abc import ABC, abstractmethod
from typing import Any

logger = logging.getLogger(__name__)


class EmbeddingProvider(ABC):
    """文本嵌入提供者的抽象基类。"""

    @abstractmethod
    def embed(self, text: str) -> list[float]:
        """将文本转换为嵌入向量。

        Args:
            text: 输入文本

        Returns:
            嵌入向量（float 列表）
        """

    @abstractmethod
    def embed_many(self, texts: list[str]) -> list[list[float]]:
        """批量将文本转换为嵌入向量。"""


class HFTextVectorizer(EmbeddingProvider):
    """使用 HuggingFace sentence-transformers 模型生成嵌入。"""

    def __init__(
        self,
        model: str = "sentence-transformers/all-MiniLM-L6-v2",
        device: str = "cpu",
        cache: Any = None,
    ):
        self.model_name = model
        self.device = device
        self.cache = cache
        self._model = None

    def _lazy_load(self):
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer

                self._model = SentenceTransformer(self.model_name, device=self.device)
            except ImportError:
                raise ImportError(
                    "请安装 sentence-transformers: pip install sentence-transformers"
                )

    def embed(self, text: str) -> list[float]:
        if self.cache:
            cached = self.cache.get(text)
            if cached is not None:
                return cached

        self._lazy_load()
        embedding = self._model.encode(text).tolist()

        if self.cache:
            self.cache.store(text, embedding)

        return embedding

    def embed_many(self, texts: list[str]) -> list[list[float]]:
        self._lazy_load()
        embeddings = self._model.encode(texts).tolist()
        return embeddings


class OpenAIEmbedding(EmbeddingProvider):
    """使用 OpenAI API 生成嵌入。"""

    def __init__(
        self,
        model: str = "text-embedding-3-small",
        api_key: str | None = None,
        base_url: str | None = None,
        cache: Any = None,
    ):
        self.model_name = model
        self.api_key = api_key
        self.base_url = base_url
        self.cache = cache
        self._client = None

    def _lazy_load(self):
        if self._client is None:
            try:
                from openai import OpenAI

                self._client = OpenAI(api_key=self.api_key, base_url=self.base_url)
            except ImportError:
                raise ImportError("请安装 openai: pip install openai")

    def embed(self, text: str) -> list[float]:
        if self.cache:
            cached = self.cache.get(text)
            if cached is not None:
                return cached

        self._lazy_load()
        resp = self._client.embeddings.create(input=text, model=self.model_name)
        embedding = resp.data[0].embedding

        if self.cache:
            self.cache.store(text, embedding)

        return embedding

    def embed_many(self, texts: list[str]) -> list[list[float]]:
        self._lazy_load()
        resp = self._client.embeddings.create(input=texts, model=self.model_name)
        embeddings = [d.embedding for d in resp.data]
        return embeddings


class OllamaEmbedding(EmbeddingProvider):
    """使用本地 Ollama 模型生成嵌入。"""

    def __init__(
        self,
        model: str = "nomic-embed-text",
        base_url: str = "http://localhost:11434",
        cache: Any = None,
    ):
        self.model_name = model
        self.base_url = base_url.rstrip("/")
        self.cache = cache

    def embed(self, text: str) -> list[float]:
        if self.cache:
            cached = self.cache.get(text)
            if cached is not None:
                return cached

        import httpx

        resp = httpx.post(
            f"{self.base_url}/api/embeddings",
            json={"model": self.model_name, "prompt": text},
        )
        resp.raise_for_status()
        embedding = resp.json()["embedding"]

        if self.cache:
            self.cache.store(text, embedding)

        return embedding

    def embed_many(self, texts: list[str]) -> list[list[float]]:
        return [self.embed(t) for t in texts]
