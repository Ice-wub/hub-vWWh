"""测试 redis_ai_cache 各模块与 Docker Redis 的集成。"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

REDIS_URL = "redis://localhost:6379"


class DummyEmbedding:
    """不依赖外部模型的伪嵌入（用于测试）。"""
    def __init__(self, cache=None):
        self.cache = cache

    def embed(self, text: str):
        import hashlib
        h = hashlib.md5(text.encode()).digest()
        return [b / 255 for b in h[:8]]

    def embed_many(self, texts):
        return [self.embed(t) for t in texts]

def test_connection():
    """1. 测试 Redis 连接"""
    print("=" * 50)
    print("1. 测试 Redis 连接")
    print("=" * 50)
    from redis_ai_cache.core.connection import get_redis_client, close_all_connections

    client = get_redis_client(REDIS_URL)
    pong = client.ping()
    print(f"  Redis PING: {pong}")
    assert pong, "Redis 连接失败"
    print("  [OK] 连接成功")
    close_all_connections()


def test_semantic_cache():
    """2. 测试语义缓存"""
    print("\n" + "=" * 50)
    print("2. 测试语义缓存 (SemanticCache)")
    print("=" * 50)
    from redis_ai_cache.cache.semantic_cache import SemanticCache

    cache = SemanticCache(
        name="test_cache",
        redis_url=REDIS_URL,
        ttl=300,
        distance_threshold=0.3,
        embedding_provider=DummyEmbedding(),  # noqa: F821
    )
    cache.clear()

    # 存储
    cache.store("中国的首都是什么？", "北京")
    cache.store("法国的首都是什么？", "巴黎")
    print("  存储了 2 条问答")

    # 检查（完全匹配）
    results = cache.check("中国的首都是什么？")
    assert len(results) > 0, "完全匹配应命中缓存"
    print(f"  完全匹配: {results[0]['response']} (distance={results[0]['distance']})")
    assert results[0]["response"] == "北京"

    # 检查（语义相似）
    results = cache.check("中国首都是哪个城市？")
    if results:
        print(f"  语义相似: '{results[0]['response']}' (distance={results[0]['distance']})")
    else:
        print("  语义相似: 未命中（距离阈值可能需要调大）")

    # 检查（不相关）
    results = cache.check("今天天气怎么样？")
    print(f"  不相关查询: {'未命中 [OK]' if not results else '命中数=' + str(len(results))}")

    cache.clear()
    print("  [OK] 语义缓存测试完成")


def test_embedding_cache():
    """3. 测试嵌入缓存"""
    print("\n" + "=" * 50)
    print("3. 测试嵌入缓存 (EmbeddingCache)")
    print("=" * 50)
    from redis_ai_cache.cache.embedding_cache import EmbeddingCache

    ec = EmbeddingCache(name="test_embed", redis_url=REDIS_URL, ttl=300)
    ec.clear()

    # 存储
    ec.store("机器学习", [0.1, 0.2, 0.3, 0.4])
    print("  存储了一条嵌入")

    # 获取
    result = ec.get("机器学习")
    assert result is not None, "应命中缓存"
    assert len(result) == 4
    print(f"  命中缓存: {result}")

    # 未命中
    result = ec.get("深度学习")
    assert result is None
    print("  不存在的键返回 None [OK]")

    ec.clear()
    print("  [OK] 嵌入缓存测试完成")


def test_message_history():
    """4. 测试对话历史"""
    print("\n" + "=" * 50)
    print("4. 测试对话历史 (SemanticMessageHistory)")
    print("=" * 50)
    from redis_ai_cache.message.history import SemanticMessageHistory

    history = SemanticMessageHistory(
        name="test_session",
        redis_url=REDIS_URL,
        distance_threshold=0.5,
        embedding_provider=DummyEmbedding(),  # noqa: F821
    )
    history.clear()

    # 添加消息
    history.add_messages([
        {"role": "user", "content": "你好"},
        {"role": "llm", "content": "你好！有什么可以帮助你的？"},
        {"role": "user", "content": "今天北京天气怎么样？"},
        {"role": "llm", "content": "北京今天晴天，气温20-25度。"},
        {"role": "user", "content": "帮我推荐一本机器学习的书"},
        {"role": "llm", "content": "推荐《统计学习方法》，李航著。"},
    ])
    print("  添加了 6 条消息")

    # 获取最近
    recent = history.get_recent(3)
    print(f"  最近 3 条消息: {len(recent)} 条")
    assert len(recent) == 3
    assert recent[0]["role"] == "llm", f"最新的消息应为 llm, 实际={recent[0]['role']}"

    # 语义搜索
    results = history.search("天气", k=2)
    print(f"  搜索 '天气': {len(results)} 条结果")
    for r in results:
        print(f"    - [{r['role']}] {r['content'][:30]} (distance={r.get('distance', 'N/A')})")

    history.clear()
    print("  [OK] 对话历史测试完成")


def test_semantic_router():
    """5. 测试语义路由"""
    print("\n" + "=" * 50)
    print("5. 测试语义路由 (SemanticRouter)")
    print("=" * 50)

    # 使用简单嵌入（不依赖外部模型）
    from redis_ai_cache.router.semantic_router import Route, SemanticRouter

    routes = [
        Route(name="greeting", references=["你好", "早上好", "hello"], distance_threshold=0.3),
        Route(name="farewell", references=["再见", "拜拜", "goodbye"], distance_threshold=0.3),
        Route(name="weather", references=["天气", "温度", "下雨"], distance_threshold=0.3),
    ]

    router = SemanticRouter(
        name="test_router",
        routes=routes,
        redis_url=REDIS_URL,
        embedding_provider=DummyEmbedding(),  # noqa: F821
        enable_cache=True,
    )

    tests = [
        ("你好呀", "greeting"),
        ("拜拜了您嘞", "farewell"),
        ("今天会下雨吗", "weather"),
    ]

    for query, expected in tests:
        result = router(query)
        status = f"[OK] {result.name}" if result and result.name == expected else f"[FAIL] 期望={expected}, 实际={result.name if result else 'None'}"
        print(f"  '{query}' -> {status}")

    print("  [OK] 语义路由测试完成")


def test_vector_schema():
    """6. 测试向量模式定义"""
    print("\n" + "=" * 50)
    print("6. 测试向量模式 (VectorIndexSchema)")
    print("=" * 50)
    from redis_ai_cache.vector.schema import (
        VectorIndexSchema, Field, FieldType,
        VectorAlgorithm, DistanceMetric
    )

    schema = VectorIndexSchema(
        name="test_idx",
        vector_dimensions=384,
        vector_algorithm=VectorAlgorithm.FLAT,
        distance_metric=DistanceMetric.COSINE,
        fields=[
            Field(name="category", field_type=FieldType.TAG, sortable=True),
            Field(name="price", field_type=FieldType.NUMERIC, sortable=True),
        ],
        prefix="vec",
    )

    cmd = schema.to_redis_create_command()
    print(f"  FT.CREATE 命令参数:")
    print(f"    索引名: {schema.name}")
    print(f"    算法: {schema.vector_algorithm.value}")
    print(f"    距离: {schema.distance_metric.value}")
    print(f"    维度: {schema.vector_dimensions}")
    print(f"    字段: {[f.name for f in schema.fields]}")
    print(f"    前缀: {schema.prefix}")
    print(f"    参数长度: {len(cmd)}")
    print("  [OK] 向量模式定义测试完成")


def test_vector_search():
    """7. 测试向量搜索（需要 docker Redis 有 search module）"""
    print("\n" + "=" * 50)
    print("7. 测试向量搜索 (VectorSearch)")
    print("=" * 50)
    from redis_ai_cache.vector.schema import (
        VectorIndexSchema, Field, FieldType,
        VectorAlgorithm, DistanceMetric
    )
    from redis_ai_cache.vector.search import VectorSearch

    # 检查 Redis 是否有 Search 模块
    from redis_ai_cache.core.connection import get_redis_client
    client = get_redis_client(REDIS_URL)
    modules_info = client.execute_command("MODULE LIST")
    modules_str = str(modules_info).lower()
    has_search = "search" in modules_str or "redisearch" in modules_str or "ft" in modules_str
    print(f"  Redis Search 模块: {'[OK] 已加载' if has_search else '[FAIL] 未加载'}")

    if not has_search:
        print("  [SKIP] 跳过向量搜索测试（需要 RediSearch 模块）")
        return

    schema = VectorIndexSchema(
        name="test_vs_idx",
        vector_dimensions=4,
        vector_algorithm=VectorAlgorithm.FLAT,
        distance_metric=DistanceMetric.COSINE,
        fields=[
            Field(name="category", field_type=FieldType.TAG),
        ],
        prefix="vs",
    )

    vs = VectorSearch(schema=schema, redis_url=REDIS_URL)
    vs.drop_index()
    vs.create_index()
    print("  索引已创建")

    # 插入数据
    vs.insert("doc1", [1.0, 0.0, 0.0, 0.0], {"category": "tech"})
    vs.insert("doc2", [0.0, 1.0, 0.0, 0.0], {"category": "sports"})
    vs.insert("doc3", [0.5, 0.5, 0.0, 0.0], {"category": "tech"})
    print("  已插入 3 条数据")

    # 搜索
    results = vs.search([1.0, 0.1, 0.0, 0.0], top_k=3)
    print(f"  搜索结果: {len(results)} 条")
    for r in results:
        print(f"    id={r['id']}, score={r.get('score', 'N/A')}, category={r.get('category', 'N/A')}")
    assert len(results) == 3, f"应返回 3 条结果, 实际 {len(results)}"
    assert results[0]["id"] == "vs:doc1", "最相似的应为 doc1"
    assert results[0]["score"] < 0.1, "doc1 应非常接近"

    # 带过滤搜索
    results_filtered = vs.search([0.0, 1.0, 0.0, 0.0], top_k=3, filters="@category:{sports}")
    print(f"  过滤搜索 (sports): {len(results_filtered)} 条")
    for r in results_filtered:
        print(f"    id={r['id']}, score={r.get('score', 'N/A')}")
    assert len(results_filtered) == 1, f"sports 过滤应返回 1 条"
    assert results_filtered[0]["id"] == "vs:doc2"

    vs.drop_index()
    print("  [OK] 向量搜索测试完成")


if __name__ == "__main__":
    print(">>> 开始集成测试\n")

    tests = [
        test_connection,
        test_semantic_cache,
        test_embedding_cache,
        test_message_history,
        test_semantic_router,
        test_vector_schema,
        test_vector_search,
    ]

    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"  [FAIL] 测试失败: {e}")
            import traceback
            traceback.print_exc()
            failed += 1

    print("\n" + "=" * 50)
    print(f"[RESULT] 测试结果: {passed} 通过, {failed} 失败")
    print("=" * 50)
