import logging
from dataclasses import dataclass, field
from typing import Any

from redis_ai_cache.core.base import RedisComponent
from redis_ai_cache.core.embedding import EmbeddingProvider, HFTextVectorizer
from redis_ai_cache.cache.semantic_cache import cosine_similarity

logger = logging.getLogger(__name__)


@dataclass
class Route:
    """带有参考示例的路由目标。

    Args:
        name: 路由名称（意图类别）
        references: 该路由的参考示例短语列表
        metadata: 附加信息
        distance_threshold: 匹配该路由的最大余弦距离（默认 0.3）
    """

    name: str
    references: list[str] = field(default_factory=list)
    metadata: dict[str, Any] | None = None
    distance_threshold: float = 0.3


class SemanticRouter(RedisComponent):
    """使用语义相似度将查询路由到意图类别。

    先计算查询的嵌入向量，与所有路由的参考示例比较相似度，
    将查询路由到最匹配的路由。

    Args:
        name: 路由名称（用作 Redis 键前缀）
        routes: Route 对象列表
        redis_url: Redis 连接 URL
        embedding_provider: 嵌入提供者
        enable_cache: 是否缓存路由结果（默认 True）
        cache_ttl: 路由结果缓存 TTL（秒，默认 3600）
    """

    def __init__(
        self,
        name: str,
        routes: list[Route],
        redis_url: str = "redis://localhost:6379",
        embedding_provider: EmbeddingProvider | None = None,
        enable_cache: bool = True,
        cache_ttl: int = 3600,
    ):
        super().__init__(name=name, redis_url=redis_url, ttl=cache_ttl)
        self.routes: dict[str, Route] = {r.name: r for r in routes}
        self.embedding_provider = embedding_provider or HFTextVectorizer()
        self.enable_cache = enable_cache

        # 预计算所有路由参考示例的嵌入向量
        self._reference_embeddings: dict[str, list[tuple[str, list[float]]]] = {}
        self._build_reference_embeddings()

    def _build_reference_embeddings(self) -> None:
        """预计算所有路由参考示例的嵌入向量。"""
        for route_name, route in self.routes.items():
            embeddings = []
            for ref in route.references:
                try:
                    emb = self.embedding_provider.embed(ref)
                    embeddings.append((ref, emb))
                except Exception as e:
                    logger.warning("路由 '%s' 参考示例嵌入失败: %s", route_name, e)
            self._reference_embeddings[route_name] = embeddings

    def __call__(self, query: str) -> Route | None:
        """将查询路由到最佳匹配的意图类别。

        Args:
            query: 用户查询

        Returns:
            最佳匹配的 Route，无匹配返回 None
        """
        # 检查缓存
        if self.enable_cache:
            cached = self._check_cache(query)
            if cached is not None:
                return cached

        # 计算查询嵌入
        try:
            query_embedding = self.embedding_provider.embed(query)
        except Exception as e:
            logger.warning("查询嵌入计算失败: %s", e)
            return None

        # 在所有路由的参考示例中找最佳匹配
        best_route: Route | None = None
        best_distance = float("inf")

        for route_name, refs in self._reference_embeddings.items():
            for _, ref_embedding in refs:
                dist = cosine_similarity(query_embedding, ref_embedding)
                route = self.routes[route_name]
                if dist <= route.distance_threshold and dist < best_distance:
                    best_distance = dist
                    best_route = route

        # 缓存结果
        if self.enable_cache and best_route is not None:
            self._cache_result(query, best_route.name)

        return best_route

    def add_route(self, route: Route) -> None:
        """动态添加路由。"""
        self.routes[route.name] = route
        # 预计算新路由的参考示例嵌入
        embeddings = []
        for ref in route.references:
            try:
                emb = self.embedding_provider.embed(ref)
                embeddings.append((ref, emb))
            except Exception as e:
                logger.warning("路由 '%s' 参考示例嵌入失败: %s", route.name, e)
        self._reference_embeddings[route.name] = embeddings

    def list_routes(self) -> list[Route]:
        """列出所有注册的路由。"""
        return list(self.routes.values())

    def clear(self) -> None:
        """清除路由缓存。"""
        try:
            keys = self.client.keys(self._key("cache:*"))
            if keys:
                self.client.delete(*keys)
        except Exception as e:
            logger.warning("SemanticRouter.clear 失败: %s", e)

    def _check_cache(self, query: str) -> Route | None:
        """检查查询是否已有缓存的路由结果。"""
        try:
            cache_key = self._key("cache", self._query_hash(query))
            cached = self.client.get(cache_key)
            if cached:
                route_name = cached.decode() if isinstance(cached, bytes) else cached
                return self.routes.get(route_name)
        except Exception as e:
            logger.warning("路由缓存读取失败: %s", e)
        return None

    def _cache_result(self, query: str, route_name: str) -> None:
        """缓存查询的路由结果。"""
        try:
            cache_key = self._key("cache", self._query_hash(query))
            self.client.set(cache_key, route_name)
            if self.ttl:
                self.client.expire(cache_key, self.ttl)
        except Exception as e:
            logger.warning("路由缓存写入失败: %s", e)

    @staticmethod
    def _query_hash(query: str) -> str:
        """对查询取哈希。"""
        import hashlib
        return hashlib.md5(query.encode("utf-8")).hexdigest()
