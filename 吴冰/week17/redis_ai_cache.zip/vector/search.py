import logging
from typing import Any, List, Dict, Optional

from redis_ai_cache.core.base import RedisComponent
from redis_ai_cache.vector.schema import VectorIndexSchema

logger = logging.getLogger(__name__)


class VectorSearch(RedisComponent):
    """向量检索引擎，支持混合查询。

    Args:
        schema: 向量索引模式定义
        redis_url: Redis 连接 URL
    """

    def __init__(
        self,
        schema: VectorIndexSchema,
        redis_url: str = "redis://localhost:6379",
    ):
        super().__init__(name=schema.name, redis_url=redis_url)
        self.schema = schema

    def create_index(self) -> bool:
        """创建向量索引。

        如果索引已存在，不会重复创建。

        Returns:
            是否成功
        """
        try:
            self.client.execute_command(*self.schema.to_redis_create_command())
            logger.info("索引 '%s' 创建成功", self.schema.name)
            return True
        except Exception as e:
            if "already exists" in str(e).lower():
                logger.info("索引 '%s' 已存在", self.schema.name)
                return True
            logger.warning("创建索引失败: %s", e)
            return False

    def drop_index(self) -> bool:
        """删除索引。"""
        try:
            self.client.execute_command("FT.DROPINDEX", self.schema.name)
            return True
        except Exception as e:
            logger.warning("删除索引失败: %s", e)
            return False

    def search(
        self,
        query_vector: list[float],
        top_k: int = 10,
        filters: str | None = None,
    ) -> list[dict[str, Any]]:
        """执行向量相似度搜索，可选元数据过滤。

        Args:
            query_vector: 查询向量
            top_k: 返回结果数
            filters: 过滤表达式（如 "@category:TAG {tech}"）

        Returns:
            匹配结果列表，包含 id、score、metadata 等字段
        """
        import struct

        vector_bytes = struct.pack(f"{len(query_vector)}f", *query_vector)

        if filters:
            query = f"({filters})=>[KNN {top_k} @vector $vec AS score]"
        else:
            query = f"*=>[KNN {top_k} @vector $vec AS score]"

        try:
            raw = self.client.execute_command(
                "FT.SEARCH", self.schema.name,
                query,
                "PARAMS", "2", "vec", vector_bytes,
                "SORTBY", "score", "ASC",
                "RETURN", "3", "score", "id", "category",
                "DIALECT", "2",
            )
        except Exception as e:
            logger.warning("向量搜索失败: %s", e)
            return []

        return self._decode_search_response(raw)

    def _decode_search_response(self, raw):
        """解析 FT.SEARCH 返回结果，兼容字节和字符串 key。"""
        if not isinstance(raw, (dict, list)):
            return []

        results = []
        # decode_responses=True -> 字符串 key, False -> 字节 key
        raw_items = raw.get(b"results") or raw.get("results") or []
        for item in raw_items:
            attrs = item.get(b"extra_attributes") or item.get("extra_attributes") or {}
            entry = {
                "id": self._decode_val(item.get(b"id") or item.get("id", "")),
                "score": float(self._decode_val(attrs.get(b"score") or attrs.get("score", "0"))),
            }
            for k, v in attrs.items():
                key = self._decode_val(k)
                if key not in ("score", "vector"):
                    entry[key] = self._decode_val(v) if isinstance(v, (bytes, str)) else v
            results.append(entry)
        return results

    @staticmethod
    def _decode_val(v):
        if isinstance(v, bytes):
            return v.decode("utf-8", errors="replace")
        return v

    def insert(self, doc_id: str, vector: list[float], metadata: dict[str, Any] | None = None) -> bool:
        """插入向量数据。

        使用 Redis HASH 存储，与索引前缀匹配。
        """
        import struct

        key = f"{self.schema.prefix}:{doc_id}"
        data = {
            "vector": struct.pack(f"{len(vector)}f", *vector),
        }
        if metadata:
            data.update(metadata)

        try:
            self.client.hset(key, mapping=data)
            return True
        except Exception as e:
            logger.warning("插入向量数据失败: %s", e)
            return False

    def clear(self) -> None:
        """删除所有匹配前缀的键（不删除索引）。"""
        try:
            keys = self.client.keys(f"{self.schema.prefix}:*")
            if keys:
                self.client.delete(*keys)
        except Exception as e:
            logger.warning("VectorSearch.clear 失败: %s", e)
