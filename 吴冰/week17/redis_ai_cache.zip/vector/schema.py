from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class FieldType(str, Enum):
    TAG = "TAG"
    NUMERIC = "NUMERIC"
    TEXT = "TEXT"
    GEO = "GEO"


class VectorAlgorithm(str, Enum):
    FLAT = "FLAT"
    HNSW = "HNSW"


class DistanceMetric(str, Enum):
    COSINE = "COSINE"
    IP = "IP"
    L2 = "L2"


@dataclass
class Field:
    """元数据字段定义。"""

    name: str
    field_type: FieldType = FieldType.TEXT
    sortable: bool = False
    no_index: bool = False


@dataclass
class VectorIndexSchema:
    """定义 Redis 向量检索索引。

    Args:
        name: 索引名称
        vector_dimensions: 向量维度
        vector_algorithm: 向量算法（FLAT / HNSW）
        distance_metric: 距离度量（COSINE / IP / L2）
        fields: 元数据字段列表
        prefix: Redis 键前缀
    """

    name: str = "idx"
    vector_dimensions: int = 384
    vector_algorithm: VectorAlgorithm = VectorAlgorithm.FLAT
    distance_metric: DistanceMetric = DistanceMetric.COSINE
    fields: list[Field] = field(default_factory=list)
    prefix: str = "vec"

    def to_redis_create_command(self) -> list[str]:
        """生成 Redis FT.CREATE 命令参数列表。"""
        args = [
            "FT.CREATE",
            self.name,
            "ON",
            "HASH",
            "PREFIX",
            "1",
            self.prefix,
            "SCHEMA",
        ]

        for field in self.fields:
            field_type = field.field_type.value
            args.append(field.name)
            args.append(field_type)
            if field.sortable:
                args.append("SORTABLE")
            if field.no_index:
                args.append("NOINDEX")

        args.extend([
            "vector",
            "VECTOR",
            self.vector_algorithm.value,
            "6",
            "TYPE",
            "FLOAT32",
            "DIM",
            str(self.vector_dimensions),
            "DISTANCE_METRIC",
            self.distance_metric.value,
        ])

        return args
