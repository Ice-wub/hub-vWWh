"""redis_ai_cache API 服务器 — 前端管理界面的后端。"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import logging
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from redis_ai_cache.core.connection import get_redis_client, close_all_connections
from redis_ai_cache.cache.semantic_cache import SemanticCache
from redis_ai_cache.cache.embedding_cache import EmbeddingCache
from redis_ai_cache.router.semantic_router import Route, SemanticRouter
from redis_ai_cache.core.embedding import EmbeddingProvider

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
logger = logging.getLogger(__name__)

REDIS_URL = "redis://localhost:6379"

# ---------------------------------------------------------------------------
# 嵌入提供者（简化版，不依赖外部模型）
# ---------------------------------------------------------------------------

class SimpleEmbedder(EmbeddingProvider):
    def embed(self, text: str) -> list[float]:
        import hashlib
        h = hashlib.md5(text.encode()).digest()
        return [b / 255 for b in h[:8]]

    def embed_many(self, texts: list[str]) -> list[list[float]]:
        return [self.embed(t) for t in texts]

_embedder = SimpleEmbedder()

# ---------------------------------------------------------------------------
# 缓存实例
# ---------------------------------------------------------------------------

_semantic: SemanticCache | None = None
_embed_cache: EmbeddingCache | None = None
_router: SemanticRouter | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _semantic, _embed_cache, _router
    _semantic = SemanticCache("api_cache", redis_url=REDIS_URL, distance_threshold=0.25, embedding_provider=_embedder)
    _embed_cache = EmbeddingCache("api_embed", redis_url=REDIS_URL, ttl=3600)
    _router = SemanticRouter(
        "api_router", redis_url=REDIS_URL, embedding_provider=_embedder, enable_cache=True,
        routes=[
            Route("greeting", ["你好", "hello", "早上好", "下午好"]),
            Route("farewell", ["再见", "拜拜", "goodbye", "明天见"]),
            Route("weather", ["天气", "温度", "下雨", "晴天", "刮风"]),
            Route("knowledge", ["知识", "什么是", "解释", "原因", "为什么"]),
        ],
    )
    yield
    close_all_connections()


app = FastAPI(title="Redis AI Cache Console", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ---------------------------------------------------------------------------
# API 路由
# ---------------------------------------------------------------------------

@app.get("/api/ping")
def ping():
    r = get_redis_client(REDIS_URL)
    return {"ok": r.ping()}


# ---- 语义缓存 ---------------------------------------------------------------

class SemanticStoreRequest(BaseModel):
    prompt: str
    response: str
    metadata: dict[str, Any] = {}


class SemanticCheckRequest(BaseModel):
    prompt: str
    k: int = 5


@app.get("/api/semantic/stats")
def semantic_stats():
    """获取语义缓存统计信息。"""
    if not _semantic:
        raise HTTPException(503, "缓存未初始化")
    try:
        keys = _semantic.client.keys(_semantic._key("*"))
        return {"total": len(keys)}
    except Exception as e:
        raise HTTPException(500, str(e))


@app.post("/api/semantic/store")
def semantic_store(req: SemanticStoreRequest):
    if not _semantic:
        raise HTTPException(503, "缓存未初始化")
    eid = _semantic.store(req.prompt, req.response, req.metadata)
    return {"id": eid}


@app.post("/api/semantic/check")
def semantic_check(req: SemanticCheckRequest):
    if not _semantic:
        raise HTTPException(503, "缓存未初始化")
    results = _semantic.check(req.prompt, req.k)
    return {"results": results, "count": len(results)}


@app.post("/api/semantic/clear")
def semantic_clear():
    if not _semantic:
        raise HTTPException(503, "缓存未初始化")
    _semantic.clear()
    return {"ok": True}


@app.get("/api/semantic/entries")
def semantic_entries():
    """列出语义缓存所有条目。"""
    if not _semantic:
        raise HTTPException(503, "缓存未初始化")
    try:
        keys = _semantic.client.keys(_semantic._key("*"))
        entries = []
        for k in keys:
            data = _semantic.client.hgetall(k)
            entries.append({
                "id": data.get(b"id", data.get("id", b"")).decode() if isinstance(data.get(b"id", data.get("id", b"")), bytes) else data.get("id", ""),
                "prompt": data.get(b"prompt", data.get("prompt", b"")).decode()[:80] if isinstance(data.get(b"prompt", data.get("prompt", b"")), bytes) else data.get("prompt", "")[:80],
                "response": data.get(b"response", data.get("response", b"")).decode()[:80] if isinstance(data.get(b"response", data.get("response", b"")), bytes) else data.get("response", "")[:80],
            })
        return {"entries": entries, "total": len(entries)}
    except Exception as e:
        raise HTTPException(500, str(e))


# ---- 嵌入缓存 ---------------------------------------------------------------

class EmbedStoreRequest(BaseModel):
    text: str
    embedding: list[float]


@app.get("/api/embed/stats")
def embed_stats():
    if not _embed_cache:
        raise HTTPException(503, "缓存未初始化")
    try:
        keys = _embed_cache.client.keys(_embed_cache._key("*"))
        return {"total": len(keys)}
    except Exception as e:
        raise HTTPException(500, str(e))


@app.post("/api/embed/store")
def embed_store(req: EmbedStoreRequest):
    if not _embed_cache:
        raise HTTPException(503, "缓存未初始化")
    ok = _embed_cache.store(req.text, req.embedding)
    return {"ok": ok}


@app.get("/api/embed/get")
def embed_get(text: str):
    if not _embed_cache:
        raise HTTPException(503, "缓存未初始化")
    emb = _embed_cache.get(text)
    return {"found": emb is not None, "embedding": emb}


@app.post("/api/embed/clear")
def embed_clear():
    if not _embed_cache:
        raise HTTPException(503, "缓存未初始化")
    _embed_cache.clear()
    return {"ok": True}


# ---- 语义路由 ---------------------------------------------------------------

class RouteRequest(BaseModel):
    query: str


@app.get("/api/router/routes")
def router_routes():
    if not _router:
        raise HTTPException(503, "路由未初始化")
    return {"routes": [{"name": r.name, "references": r.references} for r in _router.list_routes()]}


@app.post("/api/router/classify")
def router_classify(req: RouteRequest):
    if not _router:
        raise HTTPException(503, "路由未初始化")
    result = _router(req.query)
    return {"route": result.name if result else None}


# ---- 系统 -------------------------------------------------------------------

@app.get("/api/health")
def health():
    try:
        r = get_redis_client(REDIS_URL)
        redis_ok = r.ping()
    except Exception:
        redis_ok = False
    return {
        "redis": redis_ok,
        "semantic_cache_total": len(_semantic.client.keys(_semantic._key("*"))) if _semantic else 0,
        "embed_cache_total": len(_embed_cache.client.keys(_embed_cache._key("*"))) if _embed_cache else 0,
    }


# ---------------------------------------------------------------------------
# 静态文件（前端）
# ---------------------------------------------------------------------------

static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
os.makedirs(static_dir, exist_ok=True)
app.mount("/", StaticFiles(directory=static_dir, html=True), name="static")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
